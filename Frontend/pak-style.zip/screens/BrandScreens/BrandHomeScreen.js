import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import BrandProfile from "./BrandProfile";
import ShowOurCollections from "./ShowOurCollections";
import AddNewItem from "./AddNewItem";
import BrandNewItems from "./BrandNewItems";
import BrandPopularItems from "./BrandPopularItems";
import BrandItem from "./BrandItem";
import clothesData from "../../data/clothesData.json"; // Import the JSON file
import { useNavigation } from "@react-navigation/native";

const Tab = createBottomTabNavigator();

const BrandHomeScreen = ({ route }) => {
  const [clothes, setClothes] = useState([]);
  const user = route.params.user;

  useEffect(() => {
    // Set clothes data from imported JSON file
    setClothes(clothesData);
  }, []);

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === "Dashboard") {
            iconName = focused
              ? require("../../assets/icons/home_selected.png")
              : require("../../assets/icons/home_unselected.png");
          } else if (route.name === "Show Our Collections") {
            iconName = focused
              ? require("../../assets/icons/browse_selected.png")
              : require("../../assets/icons/browse_unselected.png");
          } else if (route.name === "Add New Item") {
            iconName = focused
              ? require("../../assets/icons/add_selected.png")
              : require("../../assets/icons/add_unselected.png");
          } else if (route.name === "Brand Profile") {
            iconName = focused
              ? require("../../assets/icons/profile_selected.png")
              : require("../../assets/icons/profile_unselected.png");
          }

          return (
            <Image
              source={iconName}
              style={{ width: 25, height: 25, tintColor: color }}
            />
          );
        },
      })}
    >
      <Tab.Screen name="Dashboard">
        {() => <HomeScreenContent clothes={clothes} user={user} />}
      </Tab.Screen>
      <Tab.Screen name="Show Our Collections" component={ShowOurCollections} />
      <Tab.Screen name="Add New Item" component={AddNewItem} />
      <Tab.Screen
        name="Brand Profile"
        options={{ headerShown: false }} // Disable header
      >
        {({ navigation }) => (
          <BrandProfile
            user={route.params.user}
            navigation={navigation} // Pass navigation to ProfileScreen
          />
        )}
      </Tab.Screen>
      <Tab.Screen
        name="Brand's Newest Collection"
        component={BrandNewItems}
        options={{ headerShown: false, tabBarButton: () => null }} // Hide from tab bar
      />
      <Tab.Screen
        name="Brand's Popular Collection"
        component={BrandPopularItems}
        options={{ headerShown: false, tabBarButton: () => null }} // Hide from tab bar
      />
      <Tab.Screen
        name="Brand Item"
        component={BrandItem}
        options={{ headerShown: false, tabBarButton: () => null }} // Hide from tab bar
      />
    </Tab.Navigator>
  );
};

const HomeScreenContent = ({ clothes, user }) => {
  const navigation = useNavigation();

  const topSalesItems = clothes
    .filter((item) => item.brand === user.name)
    .sort((a, b) => b.sales - a.sales)
    .slice(0, 3);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity
        style={styles.box}
        onPress={() => navigation.navigate("Brand's Newest Collection")}
      >
        <Text style={styles.boxText}>Newest Collection</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.box}
        onPress={() => navigation.navigate("Brand's Popular Collection")}
      >
        <Text style={styles.boxText}>Popular Collection</Text>
      </TouchableOpacity>
      <View style={styles.salesContainer}>
        <Text style={styles.salesTitle}>Top Sales</Text>
        {topSalesItems.map((item) => (
          <View key={item.id} style={styles.itemContainer}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.textContainer}>
              <Text style={styles.itemName}>{item.name}</Text>
              <Text style={styles.itemSales}>Sales: {item.sales}</Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: "#F0F0F0",
    alignItems: "center",
    paddingVertical: 20,
  },
  box: {
    width: "80%",
    height: 150,
    margin: 20,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  boxText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  salesContainer: {
    width: "90%",
    padding: 20,
    backgroundColor: "#fff",
    borderRadius: 10,
    marginTop: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  salesTitle: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 15,
    textAlign: "center",
  },
  itemContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },
  image: {
    width: 80,
    height: 80,
    borderRadius: 10,
    marginRight: 15,
  },
  textContainer: {
    flex: 1,
  },
  itemName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
  },
  itemSales: {
    fontSize: 16,
    color: "#666",
  },
});

export default BrandHomeScreen;
